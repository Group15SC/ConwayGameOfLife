package main.view;

import main.model.Grid;

public interface IObeserver {

    void updateGrid(Grid grid);

}
