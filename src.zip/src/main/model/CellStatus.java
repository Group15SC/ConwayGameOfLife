package main.model;

public enum CellStatus {
    RED,
    BLUE,
    BLANK
}
