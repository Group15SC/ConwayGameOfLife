package main.model.initialPattern;

import main.model.initialPattern.InitialPattern;

public class Ship extends InitialPattern {

    public Ship(){
        super(new int[] {0, 0, 1, 1, 2, 2},
                new int[] {0, 1, 0, 2, 1, 2},
                10, 22, 40);
    }

}
