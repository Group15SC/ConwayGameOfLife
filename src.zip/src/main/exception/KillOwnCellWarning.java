package main.exception;

public class KillOwnCellWarning extends Exception{
}
